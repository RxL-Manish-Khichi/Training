package linksharing

class LinkResource {

    String url;

    static constraints = {

    }
}
