package linksharing

class User {


    String email;
    String userName;
    String password;
    String firstName;
    String lastName;
    Byte photo;
    Boolean admin;
    Date dateCreated;
    Date lastUpdated;

//    static hasMany = [topics: Topic, subscriptions: Subscription, resuorces: Resource,
//                      readingItems: ReadingItem, resourceRatings: ResourceRating] ;


    static constraints = {

        email(unique: true) ;
        userName(unique: true);
        firstName(blank: false, nullable: false);
        password(nullable: false, blank: false);

    }

    static mapping = {
        table: "UserTable" ;
    }

}
