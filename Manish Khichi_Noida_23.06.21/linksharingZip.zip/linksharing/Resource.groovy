package linksharing

class Resource {

    String description;
//    User createdBy;
//    Topic topic;
    Date dateCreated;
    Date dateUpdated;

    static belongsTo = [createdBy: User, topic: Topic] ;

    static constraints = {
    }
}
