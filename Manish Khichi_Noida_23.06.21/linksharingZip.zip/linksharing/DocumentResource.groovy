package linksharing

class DocumentResource {

    String filePath;


    static constraints = {

    }
}
