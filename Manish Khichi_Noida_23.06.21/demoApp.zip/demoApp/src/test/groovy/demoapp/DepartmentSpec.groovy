package demoapp

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class DepartmentSpec extends Specification implements DomainUnitTest<Department> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
