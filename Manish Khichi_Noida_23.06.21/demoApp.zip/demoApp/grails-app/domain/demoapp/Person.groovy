package demoapp

class Person {
    String name
    int age
    Date dob
    String address
    String mobile

    static constraints = {
    }
}
