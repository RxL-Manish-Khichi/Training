package demoapp

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
